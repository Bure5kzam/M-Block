# -*- coding: utf-8 -*-
"""
Created on Tue Apr  7 18:38:24 2020

@author: 고병산
"""
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt

csv_addr=r"C://Users//Administrator//Desktop//학교//졸업작품//ML//머신러닝 파이썬//Train_data.csv"
df = pd.read_csv(csv_addr)
df.head()
x = df[['toto', 'charge', 'money', 'payment', 'bonus', 'sign', 'kakaotalk', 'hotel', 'major', 'sports', 'overseas', '24h', 'percent', 'casino']]
y = df[['advertisement']]
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.8, test_size=0.2)
mlr = LinearRegression()
mlr.fit(x_train, y_train) 
my_adver = [[1, 1, 1, 16, 1, 98, 1, 0, 1, 0, 0, 1, 1, 0]] #count of word
my_predict = mlr.predict(my_adver)
print (my_predict)
y_predict = mlr.predict(x_test)
plt.scatter(y_test, y_predict, alpha=0.4)
plt.xlabel("Actual advertisement")
plt.ylabel("Predicted advertisement")
plt.title("MULTIPLE LINEAR REGRESSION")
plt.show()
#plt.scatter(df[['size_sqft']], df[['adver']], alpha=0.4)
plt.show()
print(mlr.coef_)
print(mlr.score(x_train, y_train))