from flask import Flask,jsonify,request
import numpy as np
import pytes
from pandas.core.common import flatten
from threading import Thread
from multiprocessing import Process
import time
import parmap
app = Flask(__name__)
def on_json_loading_failed_return_dict(e):
    return {}
@app.route("/")
def hello():
    return "<h1>Hello World!</h1>"

@app.route("/hello")
def hello_flask():
    return "<h1>Hello Flash!</h1>"

@app.route("/first")
def hello_first():
    return "<h3>Hello First</h3>"

@app.route('/api/echo-json', methods=['GET', 'POST', 'DELETE', 'PUT'])

def add():
    start_time = time.time()
    request.on_json_loading_failed = on_json_loading_failed_return_dict
    data = request.get_json(force=True,cache=True)
    data = list(flatten(data))
    # ... do your business logic, and return some response
    # e.g. below we're just echo-ing back the received JSON data
    print (data)
    div_list = list()
    th_list = list()
    n = 8
    for i in range(int(len(data)/n)):
        div_list.append(int(len(data)/n))
    
    procs=[]
    splited_data = np.array_split(data,n)
    splited_data = [x.tolist() for x in splited_data]
    print (splited_data)
    parmap.map(pytes.ocr_Out_Put,splited_data,pm_pbar=True, pm_processes=n)
    print("time : "+str(time.time()-start_time))
    return jsonify(data)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port="8080")