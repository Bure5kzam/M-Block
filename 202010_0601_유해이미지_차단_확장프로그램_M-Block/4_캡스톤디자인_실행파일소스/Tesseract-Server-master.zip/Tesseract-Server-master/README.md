# Tesseract-Server
Python Flask Tesseract Server

일반 광고이미지 파일 모음 주소:https://seoultechackr-my.sharepoint.com/:u:/g/personal/woonstar_seoultech_ac_kr/EV3FNxSADmBNtilj0J9Y7A8B8Lj9UPxGgaVPg3FNdoJ6uA
