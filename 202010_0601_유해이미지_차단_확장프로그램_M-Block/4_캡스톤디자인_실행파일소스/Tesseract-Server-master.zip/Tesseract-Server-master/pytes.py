try:
    import Image
except ImportError:
    from PIL import Image
import pytesseract
import urllib.request
import requests
import cv2
import io
import numpy as np


pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'


def url_to_image(url):
    response = requests.get(url)
    # print( type(response) ) # <class 'requests.models.Response'>
    img = Image.open(io.BytesIO(response.content))
    # print( type(img) ) # <class 'PIL.JpegImagePlugin.JpegImageFile'>
    return img


def ocr_Out_Put(url_list):
    for url in url_list:
        try:
            print (url)
            if "gif" in url:
                img = Image.open(requests.get(url, stream=True,headers={"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36"}).raw)
                for frame in range(0, img.n_frames, 5):
                    img.seek(frame)
                    imgrgb = img.convert('RGBA')
                    text = pytesseract.image_to_string(imgrgb, lang='kor')
                    print(text)
            else:
                ii2 = url_to_image(url)
                ii2 = cv2.cvtColor(np.float32(ii2), cv2.COLOR_BGR2GRAY)
                cv2.waitKey(0)
                img = Image.fromarray(ii2)
                print(pytesseract.image_to_string(img, lang='kor+kortest'))
        except Exception as e:
            print (e)
            continue