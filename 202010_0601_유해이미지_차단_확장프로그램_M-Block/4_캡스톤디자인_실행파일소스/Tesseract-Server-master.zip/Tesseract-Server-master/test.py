print ('hi')
